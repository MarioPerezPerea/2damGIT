package com.example.eurofit.data

class BaloonLaunch (override val note: Double, var profile: Profile, private val meters: Double,
                    override val name: String,
                    override val desc: String
) : EuroFit() {

    override fun CalcNote(): Double? {
        var retnote: Double? =null
        when(profile.age){
            15->retnote=calc15()
            16->retnote=calc16()
        }
        return retnote
    }

    fun calc15():Double?{
        if(meters in 3.80 ..4.09){
            return 2.0
        } else if(meters in 4.10 ..4.39){
            return 2.5
        }else if(meters in 4.40 ..4.69){
            return 3.0
        }else if(meters in 4.70 ..4.99){
            return 3.5
        }else if(meters in 5.00 ..5.19){
            return 4.0
        }else if(meters in 5.20 ..5.49){
            return 4.5
        }else if(meters in 5.50 ..5.79){
            return 5.0
        }else if(meters in 5.80 ..6.09){
            return 5.5
        }else if(meters in 6.10 ..6.39){
            return 6.0
        }else if(meters in 6.40 ..6.69){
            return 6.5
        }else if(meters in 6.70 ..6.99){
            return 7.0
        }else if(meters in 7.00 ..7.29){
            return 7.5
        }else if(meters in 7.30 ..7.59){
            return 8.0
        }else if(meters in 7.60 ..7.89){
            return 8.5
        }else if(meters in 7.90 ..8.19){
            return 9.0
        }else if(meters in 8.20 ..8.49){
            return 9.5
        }else if(meters >=8.50){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc16():Double?{
        if(meters in 3.80 ..4.09){
            return 2.0
        } else if(meters in 4.10 ..4.39){
            return 2.5
        }else if(meters in 4.40 ..4.69){
            return 3.0
        }else if(meters in 4.70 ..4.99){
            return 3.5
        }else if(meters in 5.00 ..5.19){
            return 4.0
        }else if(meters in 5.20 ..5.49){
            return 4.5
        }else if(meters in 5.50 ..5.79){
            return 5.0
        }else if(meters in 5.80 ..6.09){
            return 5.5
        }else if(meters in 6.10 ..6.39){
            return 6.0
        }else if(meters in 6.40 ..6.69){
            return 6.5
        }else if(meters in 6.70 ..6.99){
            return 7.0
        }else if(meters in 7.00 ..7.29){
            return 7.5
        }else if(meters in 7.30 ..7.59){
            return 8.0
        }else if(meters in 7.60 ..7.89){
            return 8.5
        }else if(meters in 7.90 ..8.19){
            return 9.0
        }else if(meters in 8.20 ..8.49){
            return 9.5
        }else if(meters >=8.50){
            return 10.0
        }else{
            return 1.0
        }
    }
}