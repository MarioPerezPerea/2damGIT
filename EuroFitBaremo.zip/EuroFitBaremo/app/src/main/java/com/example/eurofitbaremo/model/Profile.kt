package com.example.eurofit.data

class Profile (
    val name:String,
    val pass:String,
    val age:Int,
    val weight:Double,
    val height:Double,
    val sex:String){
    
    fun calImc(){}
}