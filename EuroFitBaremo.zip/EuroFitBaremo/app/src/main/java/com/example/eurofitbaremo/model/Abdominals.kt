package com.example.eurofit.data

class Abdominals(override val note: Double, val profile: Profile, val rep:Int,
                 override val desc: String
) : EuroFit() {
    override val name="Abdominal"

    override fun CalcNote(): Double? {
        var retnote: Double? =null

        when(profile.age){
            12->retnote=calc12()
            13->retnote=calc13()
            14->retnote=calc14()
            15->retnote=calc15()
            16->retnote=calc16()
        }
        return retnote
    }
    fun calc12():Double{
        if(rep<14){
            return 1.0
        }else if(rep>=30){
            return 10.0
        }else{
            var sum: Double=1.5
            for(i in 14 ..rep){
                sum=sum+0.5
            }
            return sum
        }
    }
    fun calc13():Double{
        if(rep<16){
            return 1.0
        }else if(rep>=32){
            return 10.0
        }else{
            var sum: Double=1.5
            for(i in 16 ..rep){
                sum=sum+0.5
            }
            return sum
        }
    }
    fun calc14():Double{
        if(rep<17){
            return 1.0
        }else if(rep>=33){
            return 10.0
        }else{
            var sum: Double=1.5
            for(i in 17 ..rep){
                sum=sum+0.5
            }
            return sum
        }
    }
    fun calc15():Double{
        if(rep<19){
            return 1.0
        }else if(rep>=35){
            return 10.0
        }else{
            var sum: Double=1.5
            for(i in 19 ..rep){
                sum=sum+0.5
            }
            return sum
        }
    }
    fun calc16():Double{
        if(rep<21){
            return 1.0
        }else if(rep>=37){
            return 10.0
        }else{
            var sum: Double=1.5
            for(i in 21 ..rep){
                sum=sum+0.5
            }
            return sum
        }
    }

}