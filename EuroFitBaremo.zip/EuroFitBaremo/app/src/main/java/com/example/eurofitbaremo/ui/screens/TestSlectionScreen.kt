package com.example.eurofitbaremo.ui.screens

import androidx.compose.runtime.Composable

@Composable
fun TestSelectionScreen() {
    // por terminar
}
