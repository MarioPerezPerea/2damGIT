// Speed.kt
package com.example.eurofit.data

class Speed (
    override val note: Double,
    var profile: Profile,
    private val sec: Double,
    override val name: String,
    override val desc: String
) : EuroFit() {

    override fun CalcNote(): Double? {
        return when (profile.sex.lowercase()) {
            "femenino" -> when(profile.age) {
                14 -> calc14W()
                15 -> calc15W()
                16 -> calc16W()
                else -> null
            }
            else -> when(profile.age) {
                14 -> calc14()
                15 -> calc15()
                16 -> calc16()
                else -> null
            }
        }
    }

    fun calc14(): Double {
        return when {
            sec in 0.0..13.3 -> 10.0
            sec in 13.4..13.5 -> 9.5
            sec in 13.6..13.7 -> 9.0
            sec in 13.8..13.9 -> 8.5
            sec in 14.0..14.1 -> 8.0
            sec in 14.2..14.3 -> 7.5
            sec in 14.4..14.5 -> 7.0
            sec in 14.6..14.7 -> 6.5
            sec in 14.8..14.9 -> 6.0
            sec in 15.0..15.1 -> 5.5
            sec in 15.2..15.3 -> 5.0
            sec in 15.4..15.5 -> 4.5
            sec in 15.6..15.7 -> 4.0
            sec in 15.8..15.9 -> 3.5
            sec in 16.0..16.1 -> 3.0
            sec in 16.2..16.3 -> 2.5
            sec >= 16.4 -> 2.0
            else -> 1.0
        }
    }

    fun calc15(): Double {
        return when {
            sec in 0.0..11.0 -> 10.0
            sec in 11.1..13.2 -> 9.5
            sec in 13.3..13.4 -> 9.0
            sec in 13.5..13.6 -> 8.5
            sec in 13.7..13.8 -> 8.0
            sec in 13.9..14.0 -> 7.5
            sec in 14.1..14.2 -> 7.0
            sec in 14.3..14.4 -> 6.5
            sec in 14.5..14.6 -> 6.0
            sec in 14.7..14.8 -> 5.5
            sec in 14.9..15.0 -> 5.0
            sec in 15.1..15.2 -> 4.5
            sec in 15.3..15.4 -> 4.0
            sec in 15.5..15.6 -> 3.5
            sec in 15.7..15.8 -> 3.0
            sec in 15.9..16.0 -> 2.5
            sec >= 16.1 -> 2.0
            else -> 1.0
        }
    }

    fun calc16(): Double {
        return when {
            sec in 0.0..11.0 -> 10.0
            sec in 11.1..12.8 -> 9.5
            sec in 12.9..13.0 -> 9.0
            sec in 13.1..13.2 -> 8.5
            sec in 13.3..13.4 -> 8.0
            sec in 13.5..13.6 -> 7.5
            sec in 13.7..13.8 -> 7.0
            sec in 13.9..14.0 -> 6.5
            sec in 14.1..14.2 -> 6.0
            sec in 14.3..14.4 -> 5.5
            sec in 14.5..14.6 -> 5.0
            sec in 14.7..14.8 -> 4.5
            sec in 14.9..15.0 -> 4.0
            sec in 15.1..15.2 -> 3.5
            sec in 15.3..15.4 -> 3.0
            sec in 15.5..15.7 -> 2.5
            sec >= 15.8 -> 2.0
            else -> 1.0
        }
    }

    fun calc14W(): Double {
        return when {
            sec in 0.0..14.0 -> 10.0
            sec in 14.1..14.2 -> 9.5
            sec in 14.3..14.4 -> 9.0
            sec in 14.5..14.6 -> 8.5
            sec in 14.7..14.8 -> 8.0
            sec in 14.9..15.0 -> 7.5
            sec in 15.1..15.2 -> 7.0
            sec in 15.3..15.4 -> 6.5
            sec in 15.5..15.6 -> 6.0
            sec in 15.7..15.8 -> 5.5
            sec in 15.9..16.0 -> 5.0
            sec in 16.1..16.2 -> 4.5
            sec in 16.3..16.4 -> 4.0
            sec in 16.5..16.6 -> 3.5
            sec in 16.7..16.8 -> 3.0
            sec in 16.9..17.0 -> 2.5
            sec >= 17.1 -> 2.0
            else -> 1.0
        }
    }

    fun calc15W(): Double {
        return when {
            sec in 0.0..12.0 -> 10.0
            sec in 12.1..13.0 -> 9.5
            sec in 13.1..13.2 -> 9.0
            sec in 13.3..13.4 -> 8.5
            sec in 13.5..13.6 -> 8.0
            sec in 13.7..13.8 -> 7.5
            sec in 13.9..14.0 -> 7.0
            sec in 14.1..14.2 -> 6.5
            sec in 14.3..14.4 -> 6.0
            sec in 14.5..14.6 -> 5.5
            sec in 14.7..14.8 -> 5.0
            sec in 14.9..15.0 -> 4.5
            sec in 15.1..15.2 -> 4.0
            sec in 15.3..15.4 -> 3.5
            sec in 15.5..15.6 -> 3.0
            sec in 15.7..15.8 -> 2.5
            sec >= 15.9 -> 2.0
            else -> 1.0
        }
    }

    fun calc16W(): Double {
        return when {
            sec in 0.0..12.0 -> 10.0
            sec in 12.1..13.0 -> 9.5
            sec in 13.1..13.2 -> 9.0
            sec in 13.3..13.4 -> 8.5
            sec in 13.5..13.6 -> 8.0
            sec in 13.7..13.8 -> 7.5
            sec in 13.9..14.0 -> 7.0
            sec in 14.1..14.2 -> 6.5
            sec in 14.3..14.4 -> 6.0
            sec in 14.5..14.6 -> 5.5
            sec in 14.7..14.8 -> 5.0
            sec in 14.9..15.0 -> 4.5
            sec in 15.1..15.2 -> 4.0
            sec in 15.3..15.4 -> 3.5
            sec in 15.5..15.6 -> 3.0
            sec in 15.7..15.8 -> 2.5
            sec >= 15.9 -> 2.0
            else -> 1.0
        }
    }
}
