package com.example.eurofit.data

class Cooper (override val note: Double, var profile: Profile, private val meters: Int,
              override val name: String,
              override val desc: String
) : EuroFit() {
    override fun CalcNote(): Double? {
        var retnote: Double? =null
        when(profile.age){
            12->retnote=calc12()
            13->retnote=calc13()
            14->retnote=calc14()
            15->retnote=calc15()
            16->retnote=calc16()
        }
        return retnote
    }
    fun calc12():Double{
        if(meters in 1200 ..1249){
            return 2.0
       } else if(meters in 1250 ..1299){
           return 2.5
       }else if(meters in 1300 ..1349){
           return 3.0
       }else if(meters in 1350 ..1399){
           return 3.5
       }else if(meters in 1400 ..1449){
           return 4.0
       }else if(meters in 1450 ..1499){
           return 4.5
       }else if(meters in 1500 ..1549){
           return 5.0
       }else if(meters in 1550 ..1599){
           return 5.5
       }else if(meters in 1600 ..1649){
           return 6.0
       }else if(meters in 1650 ..1699){
           return 6.5
       }else if(meters in 1700 ..1749){
           return 7.0
       }else if(meters in 1750 ..1799){
           return 7.5
       }else if(meters in 1800 ..1899){
           return 8.0
       }else if(meters in 1900 ..1999){
           return 8.5
       }else if(meters in 2000 ..2099){
           return 9.0
       }else if(meters in 2100 ..2199){
           return 9.5
       }else if(meters >=2200){
           return 10.0
       }else{
           return 1.0
       }
    }
    fun calc13():Double{
       if(meters in 1300 ..1349){
            return 2.0
        }else if(meters in 1350 ..1399){
            return 2.5
        }else if(meters in 1400 ..1449){
            return 3.0
        }else if(meters in 1450 ..1499){
            return 3.5
        }else if(meters in 1500 ..1549){
            return 4.0
        }else if(meters in 1550 ..1599){
            return 4.5
        }else if(meters in 1600 ..1649){
            return 5.0
        }else if(meters in 1650 ..1699){
            return 5.5
        }else if(meters in 1700 ..1749){
            return 6.0
        }else if(meters in 1750 ..1799){
            return 6.5
        }else if(meters in 1800 ..1849){
            return 7.0
        }else if(meters in 1850 ..1899){
            return 7.5
        }else if(meters in 1900 ..1949){
            return 8.0
        }else if(meters in 1950 ..1999){
            return 8.5
        }else if(meters in 2000 ..2049){
            return 9.0
        }else if(meters in 2050 ..2099){
           return 9.5
       }else if(meters >=2100){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc14():Double{
        if(meters in 1200 ..1249){
            return 2.0
        } else if(meters in 1250 ..1299){
            return 2.5
        }else if(meters in 1300 ..1349){
            return 3.0
        }else if(meters in 1350 ..1399){
            return 3.5
        }else if(meters in 1400 ..1449){
            return 4.0
        }else if(meters in 1450 ..1499){
            return 4.5
        }else if(meters in 1500 ..1549){
            return 5.0
        }else if(meters in 1550 ..1599){
            return 5.5
        }else if(meters in 1600 ..1649){
            return 6.0
        }else if(meters in 1650 ..1699){
            return 6.5
        }else if(meters in 1700 ..1749){
            return 7.0
        }else if(meters in 1750 ..1799){
            return 7.5
        }else if(meters in 1800 ..1899){
            return 8.0
        }else if(meters in 1900 ..1999){
            return 8.5
        }else if(meters in 2000 ..2099){
            return 9.0
        }else if(meters in 2100 ..2199){
            return 9.5
        }else if(meters >=2200){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc15():Double{
        if(meters in 1300 ..1349){
            return 2.0
        }else if(meters in 1350 ..1399){
            return 2.5
        }else if(meters in 1400 ..1449){
            return 3.0
        }else if(meters in 1450 ..1499){
            return 3.5
        }else if(meters in 1500 ..1549){
            return 4.0
        }else if(meters in 1550 ..1599){
            return 4.5
        }else if(meters in 1600 ..1649){
            return 5.0
        }else if(meters in 1650 ..1699){
            return 5.5
        }else if(meters in 1700 ..1749){
            return 6.0
        }else if(meters in 1750 ..1799){
            return 6.5
        }else if(meters in 1800 ..1849){
            return 7.0
        }else if(meters in  1850..1899){
            return 7.5
        }else if(meters in  1900 .. 1974){
            return 8.0
        }else if(meters in 1975..2049){
            return 8.5
        }else if(meters in 2050 ..2149){
            return 9.0
        }else if(meters in 2150 ..2249){
            return 9.5
        }else if(meters >=2250){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc16():Double{
        if(meters in 1350 ..1399){
            return 2.0
        }else if(meters in 1400 ..1449){
            return 2.5
        }else if(meters in 1450 ..1499){
            return 3.0
        }else if(meters in 1500 ..1549){
            return 3.5
        }else if(meters in 1550 ..1599){
            return 4.0
        }else if(meters in 1600 ..1649){
            return 4.5
        }else if(meters in 1650 ..1699){
            return 5.0
        }else if(meters in 1700 ..1749){
            return 5.5
        }else if(meters in 1750 ..1799){
            return 6.0
        }else if(meters in 1800 ..1849){
            return 6.5
        }else if(meters in 1850 ..1899){
            return 7.0
        }else if(meters in  1900..1949){
            return 7.5
        }else if(meters in  1950 .. 2024){
            return 8.0
        }else if(meters in 2025..2099){
            return 8.5
        }else if(meters in 2100 ..2199){
            return 9.0
        }else if(meters in 2200 ..2299){
            return 9.5
        }else if(meters >=2300){
            return 10.0
        }else{
            return 1.0
        }
    }
}