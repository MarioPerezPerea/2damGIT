package com.example.eurofitbaremo.ui.screens


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun IMCScreen() {
    var peso by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var imc by remember { mutableStateOf<Double?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = peso,
            onValueChange = { peso = it },
            label = { Text("Peso (kg)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = altura,
            onValueChange = { altura = it },
            label = { Text("Altura (m)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            val pesoVal = peso.toDoubleOrNull()
            val alturaVal = altura.toDoubleOrNull()
            if (pesoVal != null && alturaVal != null && alturaVal > 0) {
                imc = pesoVal / (alturaVal * alturaVal)
            }
        }) {
            Text("Calcular IMC")
        }
        Spacer(modifier = Modifier.height(16.dp))
        imc?.let {
            Text("Tu IMC es %.2f".format(it))
        }
    }
}