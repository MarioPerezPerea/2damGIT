package com.example.eurofitbaremo.data

import com.example.eurofitbaremo.R
import com.example.eurofitbaremo.model.TestItem

object TestRepository {
    val testList = listOf(
        TestItem(
            name = "Abdominales",
            category = "Fuerza",
            imageRes = R.drawable.ic_abdominals,
            description = "Evalúa la fuerza del core mediante repeticiones en un tiempo determinado.",
            url = "https://example.com/abdominales"
        ),
        TestItem(
            name = "Flexión",
            category = "Flexibilidad",
            imageRes = R.drawable.ic_flexibility,
            description = "Mide la capacidad de flexibilidad del tronco y piernas.",
            url = "https://example.com/flexion"
        ),
        TestItem(
            name = "Velocidad",
            category = "Velocidad",
            imageRes = R.drawable.ic_speed,
            description = "Evalúa el tiempo necesario para recorrer una distancia corta.",
            url = "https://example.com/velocidad"
        ),
        TestItem(
            name = "Lanzamiento",
            category = "Agilidad",
            imageRes = R.drawable.ic_throw,
            description = "Lanzamiento de balón medicinal para evaluar la agilidad y fuerza.",
            url = "https://example.com/lanzamiento"
        ),
        TestItem(
            name = "Cooper",
            category = "Resistencia",
            imageRes = R.drawable.ic_running,
            description = "Mide la distancia recorrida en 12 minutos para evaluar resistencia aeróbica.",
            url = "https://example.com/cooper"
        )
    )

    private fun TestItem(
        name: String,
        category: String,
        imageRes: Int,
        description: String,
        url: String
    ) {
    }
}
