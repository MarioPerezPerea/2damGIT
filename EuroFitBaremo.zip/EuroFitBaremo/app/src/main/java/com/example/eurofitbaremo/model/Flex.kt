package com.example.eurofit.data

class Flex(override val note: Double, var profile: Profile, private val score: Int,
           override val name: String,
           override val desc: String
) : EuroFit() {
    override fun CalcNote(): Double? {
        var retnote: Double? =null
        when(profile.age){
            12->retnote=calc12()
            13->retnote=calc13()
            14->retnote=calc14()
            15->retnote=calc15()
            16->retnote=calc16()
        }
        return retnote
    }
    fun calc12():Double{
        if(score in -20 .. -19){
            return 2.0
        } else if(score in -18 ..-17){
            return 2.5
        }else if(score in -16 ..-15){
            return 3.0
        }else if(score in -14 ..-13){
            return 3.5
        }else if(score in -12 ..-11){
            return 4.0
        }else if(score in -10 ..-9){
            return 4.5
        }else if(score in -8 ..-7){
            return 5.0
        }else if(score in -6 ..-5){
            return 5.5
        }else if(score in -4 ..-3){
            return 6.0
        }else if(score ==-2){
            return 6.5
        }else if(score ==-1){
            return 7.0
        }else if(score ==0){
            return 7.5
        }else if(score in 1 ..2){
            return 8.0
        }else if(score in 3 ..4){
            return 8.5
        }else if(score in 5 ..6){
            return 9.0
        }else if(score in 7 ..8){
            return 9.5
        }else if(score >=9){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc13():Double{
        if(score in -14 .. -13){
            return 2.0
        } else if(score in -12 ..-11){
            return 2.5
        }else if(score in -10 ..-9){
            return 3.0
        }else if(score in -8 ..-7){
            return 3.5
        }else if(score in -6 ..-5){
            return 4.0
        }else if(score in -4 ..-3){
            return 4.5
        }else if(score == -2){
            return 5.0
        }else if(score == -1){
            return 5.5
        }else if(score ==0){
            return 6.0
        }else if(score ==1){
            return 6.5
        }else if(score ==2){
            return 7.0
        }else if(score ==3){
            return 7.5
        }else if(score in 4 ..5){
            return 8.0
        }else if(score in 6 ..7){
            return 8.5
        }else if(score in 8 ..9){
            return 9.0
        }else if(score in 10 ..11){
            return 9.5
        }else if(score >=12){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc14():Double{
        if(score == -9){
            return 2.0
        } else if(score == -8){
            return 2.5
        }else if(score == -7){
            return 3.0
        }else if(score in -6 ..-5){
            return 3.5
        }else if(score in -4 ..-3){
            return 4.0
        }else if(score in -2 ..-1){
            return 4.5
        }else if(score == 0 ){
            return 5.0
        }else if(score == 1){
            return 5.5
        }else if(score == 2){
            return 6.0
        }else if(score == 3){
            return 6.5
        }else if(score == 4){
            return 7.0
        }else if(score in 5 ..6){
            return 7.5
        }else if(score in 7 ..8){
            return 8.0
        }else if(score in 9 ..10){
            return 8.5
        }else if(score in 11 ..12){
            return 9.0
        }else if(score in 13 ..14){
            return 9.5
        }else if(score >=15){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc15():Double{
        if(score ==-8){
            return 2.0
        } else if(score ==-7){
            return 2.5
        }else if(score in -6 ..-5){
            return 3.0
        }else if(score in -4 ..-3){
            return 3.5
        }else if(score in -2 ..-1){
            return 4.0
        }else if(score == 0){
            return 4.5
        }else if(score == 1){
            return 5.0
        }else if(score == 2){
            return 5.5
        }else if(score == 3){
            return 6.0
        }else if(score == 4){
            return 6.5
        }else if(score in 5 ..6){
            return 7.0
        }else if(score in 7 ..8){
            return 7.5
        }else if(score in 9 ..10){
            return 8.0
        }else if(score in 11 ..12){
            return 8.5
        }else if(score in 13 ..14){
            return 9.0
        }else if(score in 15 ..16){
            return 9.5
        }else if(score >=17){
            return 10.0
        }else{
            return 1.0
        }
    }
    fun calc16():Double{
        if(score ==-8){
            return 2.0
        } else if(score ==-7){
            return 2.5
        }else if(score in -6 ..-5){
            return 3.0
        }else if(score in -4 ..-3){
            return 3.5
        }else if(score in -2 ..-1){
            return 4.0
        }else if(score == 0){
            return 4.5
        }else if(score == 1){
            return 5.0
        }else if(score == 2){
            return 5.5
        }else if(score == 3){
            return 6.0
        }else if(score == 4){
            return 6.5
        }else if(score in 5 ..6){
            return 7.0
        }else if(score in 7 ..8){
            return 7.5
        }else if(score in 9 ..10){
            return 8.0
        }else if(score in 11 ..12){
            return 8.5
        }else if(score in 13 ..14){
            return 9.0
        }else if(score in 15 ..16){
            return 9.5
        }else if(score >=17){
            return 10.0
        }else{
            return 1.0
        }
    }
}