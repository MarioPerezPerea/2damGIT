package com.example.eurofitbaremo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.eurofitbaremo.ui.screens.IMCScreen
import com.example.eurofitbaremo.ui.theme.EuroFitBaremoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EuroFitBaremoTheme {
                IMCScreen()
            }
        }
    }
}