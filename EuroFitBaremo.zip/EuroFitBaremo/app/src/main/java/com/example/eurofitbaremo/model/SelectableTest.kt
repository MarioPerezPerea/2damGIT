package com.example.eurofitbaremo.model

data class SelectableTest(
    val test: Unit,
    var isSelected: Boolean = false
)
