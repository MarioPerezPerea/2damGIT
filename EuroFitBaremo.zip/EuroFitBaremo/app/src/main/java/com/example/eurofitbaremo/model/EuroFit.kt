package com.example.eurofit.data

abstract class EuroFit{
    abstract val name:String
    abstract val desc:String
    abstract val note:Double
    abstract fun CalcNote():Double?
}