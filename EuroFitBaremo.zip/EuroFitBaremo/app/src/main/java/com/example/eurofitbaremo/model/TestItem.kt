package com.example.eurofitbaremo.model

data class TestItem(
    val name: String,
    val category: String,
    val imageRes: Int,
    val description: String,
    val url: String
)
